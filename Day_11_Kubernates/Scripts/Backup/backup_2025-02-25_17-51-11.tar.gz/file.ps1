$name = Read-Host "Enter your name"
write-host "Welcome $name"